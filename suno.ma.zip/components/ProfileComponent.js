import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView, RefreshControl, Modal, ActivityIndicator } from 'react-native';
import { useTheme } from 'react-native-elements';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ProfileComponent = ({ isVisible, onClose }) => {
  const { theme } = useTheme();
  const [profileData, setProfileData] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchProfileData = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch('https://suno.deno.dev/touch', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          // Add any necessary headers, such as authentication tokens
        },
      });
      const data = await response.json();
      const userData = data.response.user;
      setProfileData(userData);
      await AsyncStorage.setItem('profileData', JSON.stringify(userData));
      // Store profile image and name separately for quick access in DrawerContent
      await AsyncStorage.setItem('profileImage', userData.profile_image_url);
      await AsyncStorage.setItem('profileName', `${userData.first_name} ${userData.last_name}`);
    } catch (error) {
      console.error('Error fetching profile data:', error);
      // If fetch fails, try to load from AsyncStorage
      const storedData = await AsyncStorage.getItem('profileData');
      if (storedData) {
        setProfileData(JSON.parse(storedData));
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isVisible) {
      fetchProfileData();
    }
  }, [isVisible, fetchProfileData]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchProfileData().then(() => setRefreshing(false));
  }, [fetchProfileData]);

  if (!isVisible) return null;

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <View style={styles.centeredView}>
        <View style={[styles.modalView, { backgroundColor: theme.colors.background }]}>
          {loading ? (
            <ActivityIndicator size="large" color={theme.colors.primary} />
          ) : (
            <ScrollView
              style={styles.scrollView}
              refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
              }
            >
              {profileData && (
                <>
                  <View style={styles.header}>
                    <Image
                      source={{ uri: profileData.profile_image_url }}
                      style={styles.profileImage}
                    />
                    <View style={styles.nameContainer}>
                      <Text style={[styles.name, { color: theme.colors.text }]}>
                        {profileData.first_name} {profileData.last_name}
                      </Text>
                      <Text style={[styles.email, { color: theme.colors.grey3 }]}>
                        {profileData.email_addresses[0].email_address}
                      </Text>
                    </View>
                  </View>

                  <View style={styles.infoSection}>
                    <InfoItem
                      icon="person-outline"
                      label="Username"
                      value={profileData.username || 'Not set'}
                      theme={theme}
                    />
                    <InfoItem
                      icon="call-outline"
                      label="Phone"
                      value={profileData.phone_numbers[0]?.phone_number || 'Not set'}
                      theme={theme}
                    />
                    <InfoItem
                      icon="shield-outline"
                      label="Two-Factor Auth"
                      value={profileData.two_factor_enabled ? 'Enabled' : 'Disabled'}
                      theme={theme}
                    />
                    <InfoItem
                      icon="time-outline"
                      label="Last Sign In"
                      value={new Date(profileData.last_sign_in_at).toLocaleString()}
                      theme={theme}
                    />
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Linked Accounts</Text>
                    {profileData.external_accounts.map((account, index) => (
                      <LinkedAccount
                        key={index}
                        provider={account.provider}
                        email={account.email_address}
                        theme={theme}
                      />
                    ))}
                  </View>
                </>
              )}
            </ScrollView>
          )}
          <TouchableOpacity
            style={[styles.closeButton, { backgroundColor: theme.colors.primary }]}
            onPress={onClose}
          >
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const InfoItem = ({ icon, label, value, theme }) => (
  <View style={styles.infoItem}>
    <Ionicons name={icon} size={24} color={theme.colors.primary} style={styles.infoIcon} />
    <View>
      <Text style={[styles.infoLabel, { color: theme.colors.grey3 }]}>{label}</Text>
      <Text style={[styles.infoValue, { color: theme.colors.text }]}>{value}</Text>
    </View>
  </View>
);

const LinkedAccount = ({ provider, email, theme }) => (
  <View style={styles.linkedAccount}>
    <Ionicons
      name={provider === 'oauth_google' ? 'logo-google' : 'logo-microsoft'}
      size={24}
      color={theme.colors.primary}
      style={styles.linkedAccountIcon}
    />
    <View>
      <Text style={[styles.linkedAccountProvider, { color: theme.colors.text }]}>
        {provider === 'oauth_google' ? 'Google' : 'Microsoft'}
      </Text>
      <Text style={[styles.linkedAccountEmail, { color: theme.colors.grey3 }]}>{email}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    width: '90%',
    maxHeight: '80%',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  scrollView: {
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 20,
  },
  nameContainer: {
    flex: 1,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  email: {
    fontSize: 16,
  },
  infoSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  infoIcon: {
    marginRight: 15,
  },
  infoLabel: {
    fontSize: 14,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  linkedAccount: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  linkedAccountIcon: {
    marginRight: 15,
  },
  linkedAccountProvider: {
    fontSize: 16,
    fontWeight: '500',
  },
  linkedAccountEmail: {
    fontSize: 14,
  },
  closeButton: {
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
    width: '100%',
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileComponent;